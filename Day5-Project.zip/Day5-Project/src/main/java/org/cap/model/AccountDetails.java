package org.cap.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
@Entity
public class AccountDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int accountId;
	@Column(unique=true)
private long accountNumber;
private String accountType;
private double openingBalance;
private Date openingDate;
private String status;
private int year;



@Transient
private double updateBalance;

@ManyToOne(fetch=FetchType.EAGER)
@JoinColumn(name="customerId")
private Customer customer;



@OneToMany(targetEntity=Transaction.class,mappedBy="fromAccount")
private List<Transaction> fromTransactions;

@OneToMany(targetEntity=Transaction.class,mappedBy="toAccount")
private List<Transaction> toTransactions;

public AccountDetails(int accountId, long accountNumber, String accountType, double openingBalance, Date openingDate,
		String status, int year, double updateBalance, Customer customer, List<Transaction> fromTransactions,
		List<Transaction> toTransactions) {
	super();
	this.accountId = accountId;
	this.accountNumber = accountNumber;
	this.accountType = accountType;
	this.openingBalance = openingBalance;
	this.openingDate = openingDate;
	this.status = status;
	this.year = year;
	this.updateBalance = updateBalance;
	this.customer = customer;
	this.fromTransactions = fromTransactions;
	this.toTransactions = toTransactions;
}
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public long getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(long accountNumber) {
	this.accountNumber = accountNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public Date getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(Date openingDate) {
	this.openingDate = openingDate;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public double getUpdateBalance() {
	return updateBalance;
}
public void setUpdateBalance(double updateBalance) {
	this.updateBalance = updateBalance;
}
public Customer getCustomer() {
	return customer;
}
public void setCustomer(Customer customer) {
	this.customer = customer;
}
public List<Transaction> getFromTransactions() {
	return fromTransactions;
}
public void setFromTransactions(List<Transaction> fromTransactions) {
	this.fromTransactions = fromTransactions;
}
public List<Transaction> getToTransactions() {
	return toTransactions;
}
public void setToTransactions(List<Transaction> toTransactions) {
	this.toTransactions = toTransactions;
}
@Override
public String toString() {
	return "AccountDetails [accountId=" + accountId + ", accountNumber=" + accountNumber + ", accountType="
			+ accountType + ", openingBalance=" + openingBalance + ", openingDate=" + openingDate + ", status=" + status
			+ ", year=" + year + ", updateBalance=" + updateBalance + ", customer=" + customer + ", fromTransactions="
			+ fromTransactions + ", toTransactions=" + toTransactions + "]";
}

public AccountDetails() {
	super();
}




}
