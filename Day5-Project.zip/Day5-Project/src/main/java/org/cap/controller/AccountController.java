package org.cap.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.cap.model.AccountDetails;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.IAccountService;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	@Autowired
	private ILoginService loginService;
	@Autowired
	private IAccountService accountService;
	
	@RequestMapping("/validateLogin")
	public String validatelogin(ModelMap map, @RequestParam("customerId") String customerId,
			@RequestParam("password") String password,HttpSession session) {
		
		int custId=Integer.parseInt(customerId);
		if(loginService.validateLogin(custId,password)) {
			
			session.setAttribute("custId",custId);
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			
			return "Main";
		}
		return "redirect:/";
		
	}
	@RequestMapping("/CreateAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("accountDetails", new AccountDetails());
		return"CreateAccount";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,
			@ModelAttribute("accountDetails") AccountDetails account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		account.setCustomer(customer);
		account.setStatus("active");
		accountService.createAccount(account);
		
		return "redirect:CreateAccount";
	}
	
	@RequestMapping("/ShowBalance")
	public String showAccountBalancePage(ModelMap map,HttpSession session) {
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<AccountDetails> accounts= accountService.getAccountWithBalance(custId);
		
		map.put("accounts", accounts);
		return"ShowBalance";
	}
		@RequestMapping("/DepositWithdraw")
		public String depositWithdrawOperation(ModelMap map,
				HttpSession session) {
			
			Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		
			List<AccountDetails> accounts= accountService.getAllAccounts(custId);
			map.put("accounts", accounts);
			map.put("transaction1", new Transaction());
			
			return "DepositWithdraw";
		}
		
		
		@RequestMapping("/addTransaction")
		public String addTransaction(
				@ModelAttribute("transaction1") Transaction transaction1,
				HttpSession session) {
			
			Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
			
			Customer customer= loginService.findCustomer(customerId);
			
			transaction1.setTransactionDate(new Date());
			transaction1.setStatus("completed");
			transaction1.setCustomer(customer);
			
			long accNo=transaction1.getFromAccount().getAccountNumber();
			AccountDetails account=accountService.findAccount(accNo);
			transaction1.setFromAccount(account);
			
			accountService.addTransaction(transaction1);
			
			return "redirect:DepositWithdraw";
		}
		

	@RequestMapping("/Transfer")
	public String fundTransfer(ModelMap map,HttpSession session,@ModelAttribute("transaction") Transaction transaction) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		 List<AccountDetails> accountNos=accountService.getAllAccounts(customerId);
			 map.put("accNos",accountNos);
		 List<AccountDetails> toAccountNos=accountService.getAllToAccounts(customerId);
		

		 map.put("toAccNos",toAccountNos);
		 map.put("transaction",new Transaction());
		
		return "Transfer";
		
	}

	@RequestMapping("/fundTransfer")
	public String fundTransferring(ModelMap map,HttpSession session,
			@ModelAttribute("transaction") Transaction transaction) {
		transaction.setTransactionDate(new Date());
		transaction.setStatus("Transaction successful");
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		
		transaction.setCustomer(customer);
		long accNo=transaction.getFromAccount().getAccountNumber();
		long accNo1=transaction.getToAccount().getAccountNumber();
		AccountDetails account=accountService.getAccount(accNo);
		AccountDetails account1=accountService.getAccount1(accNo1);
		transaction.setFromAccount(account);
		transaction.setToAccount(account1);
		transaction.setTransactionType("debit");
		Transaction transaction2=new Transaction();
		transaction2.setFromAccount(account1);
		transaction2.setTransactionType("credit");
	  

		accountService.fundTransfer(transaction);
		  accountService.fundTransfer(transaction2);
		
		return "redirect:/Transfer";
		
	}
	@RequestMapping("/TransactionSummary")
	public String showTransactionSummaryPage(ModelMap map,HttpSession session) {
		
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Transaction> transaction= accountService.getTransaction(custId);
		
		map.put("transactions", transaction);
		return "TransactionSummary";
	}
		@RequestMapping("/Logout")
		public String showLogoutPage(HttpSession session) {
			session.invalidate();
			return"redirect:/";
		}
}
