package org.cap.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;


import org.cap.model.AccountDetails;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	@Override
	@Transactional
	public void createAccount(AccountDetails account) {
Query query= entityManager.createQuery("select max(accountNumber) from AccountDetails");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNumber(max.get(0)+1);
		
		
		entityManager.persist(account);
	}


	


@Transactional(readOnly=true)
public Map<AccountDetails, Double> getAmoutCrDe(String strQuery,int customerId){

	
	Query query2=entityManager
			.createQuery(strQuery);
	
	query2.setParameter("custId", customerId);
	
	List<Transaction> transactions=query2.getResultList();
	Map<AccountDetails, Double> map=
	transactions.stream()
			.collect(
			Collectors.groupingBy(Transaction::getFromAccount,
				Collectors.summingDouble(Transaction::getAmount))
			);
	return map;
}



@Override
@Transactional(readOnly=true)
public List<AccountDetails> getAllAccounts(int customerId) {
	Query query= entityManager
			.createQuery("from AccountDetails acc where acc.customer.customerId=:custId");
		
		query.setParameter("custId", customerId);
		
		
		List<AccountDetails> accounts= query.getResultList();
		
		
		return accounts;
	}





@Transactional
public void addTransaction(Transaction transaction1) {
	
	entityManager.persist(transaction1);
	
}
@Transactional
@Override
public AccountDetails findAccount(long accountNo) {
	Query query= entityManager.createQuery("from AccountDetails where accountNumber=:accno");
	query.setParameter("accno", accountNo);
	List<AccountDetails> accounts= query.getResultList();
	return accounts.get(0);
}




@Transactional
@Override
public List<Transaction> getTransaction(Integer custId) {
	Query query= entityManager
			.createQuery("from Transaction tx where tx.customer.customerId=:custId");
		
		query.setParameter("custId", custId);
		
		
		List<Transaction> transaction= query.getResultList();
		
		for (Transaction transaction2 : transaction) {
			System.out.println(transaction2);
		}
		return transaction;
}

@Transactional
@Override
public AccountDetails getAccount(long accountNo) {
	Query query= entityManager.createQuery("from AccountDetails where accountNumber=:accno");
	query.setParameter("accno", accountNo);
	List<AccountDetails> accounts= query.getResultList();
	return accounts.get(0);
}

@Override
@Transactional(readOnly=true)
public List<AccountDetails> getAllToAccounts(Integer customerId) {
	Query query=entityManager.createQuery("from AccountDetails acc where acc.customer.customerId!=:custId");
	query.setParameter("custId", customerId);
	
	List<AccountDetails> accounts=query.getResultList();
	
	return accounts;
	
}

@Override
@Transactional
public void fundTransfer(Transaction transaction) {
	
    
	entityManager.persist(transaction);
	
	
}

@Override
@Transactional
public AccountDetails getAccount1(long accNo1) {
	Query query= entityManager.createQuery("from AccountDetails where accountNumber=:accno");
	query.setParameter("accno", accNo1);
	List<AccountDetails> accounts= query.getResultList();
	return accounts.get(0);
}


}
