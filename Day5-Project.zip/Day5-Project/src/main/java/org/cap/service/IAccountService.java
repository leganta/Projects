package org.cap.service;

import java.util.List;


import org.cap.model.AccountDetails;
import org.cap.model.Transaction;

public interface IAccountService {
	public void createAccount(AccountDetails account);

	public List<AccountDetails> getAccountWithBalance(Integer custId);
	
	public List<AccountDetails> getAllAccounts(int customerId);

	

	public void addTransaction(Transaction transaction1);

	public AccountDetails findAccount(long accNo);

	public List<Transaction> getTransaction(Integer custId);

	public void fundTransfer(Transaction transaction2);

	public AccountDetails getAccount(long accNo);

	public AccountDetails getAccount1(long accNo1);

	public List<AccountDetails> getAllToAccounts(Integer customerId);

	

	
}
