package com.wallet;

import java.util.HashMap;
import java.util.Scanner;


import com.wallet.bean.Wallet;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

/**
 * Hello world!
 *
 */
public class App{ 
	static HashMap<Long,Wallet > walletMap = WalletDB.getwalletMap();
	WalletService walletService= new WalletServiceImpl();
Scanner scan= new Scanner(System.in);

    public static void main( String[] args )
    {
    	
        String option = null;
        App a= new App();
        while(true) {
        	System.out.println("====Account Management System====");
        	System.out.println("1.Create Bank Account");
        	System.out.println("2.Show Account Balance");
        	System.out.println("3.Deposit");
        	System.out.println("4.Withdraw");
        	System.out.println("5.Print Transaction");
        	System.out.println("6.Fund Transfer");
        	System.out.println("7.Exit");
        	System.out.println("Choose an option");
        option = a.scan.nextLine();
        	switch(option) {
        	case"1":
        		a.createAccount();
        		break;
        	case"2":
        		a.showAccountBalance();
        		break;
        	case"3":
        		a.deposit();
        		break;
        	case"4":
        		a.withdraw();
        		break;
        	case"5":
        		a.printTransaction();
        		break;
        	case"6":
        		a.fundTransfer();
        		break;
        	case"7":
        		System.exit(0);
        		break;
        	default:
        		System.err.println("Enter option between 1 to 7");
        		System.out.println();
        		
        	}
        }
    }

	private void fundTransfer() {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Other Account Number");
		Long num1=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		String pin=(scan.nextLine());
		System.out.println("Enter Balance to Transfer");
		String balance=((scan.nextLine()));
		try {
			Wallet request=walletService.FundTransfer(num,num1, pin, balance);
			System.out.println("request");
		}
		catch (WalletException e) {
			// TODO Auto-generated catch block
			
			System.out.println();
			System.err.println("An error Occured:"+e.getMessage());
			System.out.println();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			
			System.out.println();
			System.err.println("An error Occured:"+e.getMessage());
			System.out.println();
		}
	}

	private void printTransaction() {
		// TODO Auto-generated method stub
		System.out.println("Enter account number:");
		long num = Long.parseLong(scan.nextLine());
		System.out.println("Enter pin");
		String pin = (scan.nextLine());
		try {
			Wallet request=walletService.printTransaction(num,pin);
			int pin1 = walletMap.get(num).getPinNumber();
			if (Integer.parseInt(pin) == pin1) {
				System.out.println("Transaction statement:");
			
			System.out.println();
			System.out.println(request);
			System.out.println();
			}
			else
				System.out.println("invalid pin");
	
		}
		catch (WalletException e) {
			System.err.println("An Error Occured " + e.getMessage());
			System.out.println();

		}
	}

	private void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		String pin=(scan.nextLine());
		System.out.println("Enter Balance to Withdraw");
		String balance=((scan.nextLine()));
		try {
			Wallet request=walletService.withdraw(num, pin, balance);
			System.out.println("request");
		}
		catch (WalletException e) {
			// TODO Auto-generated catch block
			
			System.out.println();
			System.err.println("An error Occured:"+e.getMessage());
			System.out.println();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			
			System.out.println();
			System.err.println("An error Occured:"+e.getMessage());
			System.out.println();
		}
	}

	private void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		String pin=((scan.nextLine()));
		System.out.println("Enter Balance to Deposit");
		String balance=((scan.nextLine()));
		
		try {
			//double Balance=Double.parseDouble(num);
				Wallet request=walletService.Deposit(num,pin,balance);
				System.out.println(request);
				
			} catch (WalletException e) {
				// TODO Auto-generated catch block
				
				System.out.println();
				System.err.println("An error Occured:"+e.getMessage());
				System.out.println();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				
				System.out.println();
				System.err.println("An error Occured:"+e.getMessage());
				System.out.println();
			}
	}

	private void showAccountBalance() {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		int pin=(Integer.parseInt(scan.nextLine()));
		try {
			//double Balance=Double.parseDouble(num);
				Wallet request=walletService.getAccountBalance(num,pin);
				System.out.println(request);
				
			} catch (WalletException e) {
				// TODO Auto-generated catch block
				
				System.out.println();
				System.err.println("An error Occured:"+e.getMessage());
				System.out.println();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				
				System.out.println();
				System.err.println("An error Occured:"+e.getMessage());
				System.out.println();
			}
			
		
	}

	private void createAccount() {
		// TODO Auto-generated method stub
		Wallet w=new Wallet();
		System.out.println("Enter Customer Name");
		w.setCustomerName(scan.nextLine());
		/*System.out.println("Enter Account Number");
		w.setAccountNumber(Long.parseLong(scan.nextLine()));*/
		System.out.println("Enter Account Type");
		w.setAccountType(scan.nextLine());
		System.out.println("Enter Account Balance");
		w.setAccountBalance(Double.parseDouble(scan.nextLine()));
		System.out.println("Enter Mobile Number");
		w.setMobile(scan.nextLine());
		System.out.println("Enter pin");
		w.setPinNumber(Integer.parseInt(scan.nextLine()));
		System.out.println("Enter Address");
		w.setAddress(scan.nextLine());
		try {
			boolean result=walletService.validateAccount(w);
			if(result) {
				long ret=walletService.createAccount(w);
				System.out.println("Customer with Account "+ ret+"Added Successfully");
			}
		
			}
			catch (WalletException e) {
				System.err.println("An error Ocuured"+e.getMessage());
				System.out.println("");
			}
	}
}
