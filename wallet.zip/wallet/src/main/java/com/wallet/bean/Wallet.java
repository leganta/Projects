package com.wallet.bean;

public class Wallet {
private String CustomerName;
private double AccountBalance;
private String AccountType;
private long AccountNumber;
private String Mobile;
private String Address;
private int PinNumber;



@Override
public String toString() {
	return "Wallet [CustomerName=" + CustomerName + ", AccountBalance=" + AccountBalance + ", "
			+ "AccountNumber=" + AccountNumber + "]";
}
public Wallet(String customerName, double accountBalance, String accountType,  long accountNumber,String mobile,
		String address, int pinNumber) {
	super();
	CustomerName = customerName;
	AccountBalance = accountBalance;
	AccountType = accountType;
	AccountNumber = accountNumber;
	Mobile = mobile;
	Address = address;
	PinNumber = pinNumber;
}
public String getCustomerName() {
	return CustomerName;
}
public void setCustomerName(String customerName) {
	CustomerName = customerName;
}
public double getAccountBalance() {
	return AccountBalance;
}
public void setAccountBalance(double accountBalance) {
	AccountBalance = accountBalance;
}
public String getAccountType() {
	return AccountType;
}
public void setAccountType(String accountType) {
	AccountType = accountType;
}
public long getAccountNumber() {
	return AccountNumber;
}
public void setAccountNumber(long accountNumber) {
	AccountNumber = accountNumber;
}
public String getMobile() {
	return Mobile;
}
public void setMobile(String mobile) {
	Mobile = mobile;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public int getPinNumber() {
	return PinNumber;
}
public void setPinNumber(int pinNumber) {
	PinNumber = pinNumber;
}
public Wallet() {
	super();
}
}
