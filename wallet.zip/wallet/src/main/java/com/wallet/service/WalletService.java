package com.wallet.service;

import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public interface WalletService {
long createAccount(Wallet w) throws WalletException;
boolean validateAccount(Wallet w) throws WalletException;
public  Wallet  getAccountBalance(long AccountNumber,int pin) throws WalletException;
public Wallet withdraw(long AccountNumber,String pin,String Balance) throws WalletException;
public Wallet FundTransfer(long AccountNumber,long AccNumber,String pin,String Balance) throws WalletException;
public Wallet Deposit(long AccountNumber,String pin,String balance) throws WalletException;
public Wallet printTransaction(Long num,String pin) throws WalletException;

}
