package com.wallet.service;


import com.wallet.bean.Wallet;
import com.wallet.dao.WalletDAO;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {
WalletDAO walletdao=new WalletDaoImpl();
	@Override
	public long createAccount(Wallet w) throws WalletException {
		// TODO Auto-generated method stub
		return walletdao.createAccount(w);
	}

	@Override
	public boolean validateAccount(Wallet w) throws WalletException {
		// TODO Auto-generated method stub
		if(validateName(w.getCustomerName())&& validateMobile(w.getMobile())) {
			return true;
		}
		
		return false;
	}
	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty() || name==null) {
			throw new WalletException("Employee Name cannot be Empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("Name should start with Capital Letter "
						+ "followed by Minimum of 2 Alphabets");
			}
		}
		
		return true;
		
	}
	private boolean validateMobile(String mobile) throws WalletException{
		if(mobile.isEmpty() || mobile==null) {
			throw new WalletException("Mobile Number is Mandatory");
		}
		else {
			if(!mobile.matches("\\d{10}")) {
			throw new WalletException("Mobile Number should contain only 10 digits");	
			}
		}
		
		return true;
	}


	@Override
	public Wallet getAccountBalance(long AccountNumber,int pin) throws WalletException {
		// TODO Auto-generated method stub
		return walletdao.getAccountBalance(AccountNumber,pin);
	}

	@Override
	public Wallet withdraw(long AccountNumber, String pin, String Balance) throws WalletException {
		// TODO Auto-generated method stub
		return walletdao.withdraw(AccountNumber,pin,Balance);
	}

	@Override
	public Wallet FundTransfer(long AccountNumber, long AccNumber, String pin, String Balance) throws WalletException {
		// TODO Auto-generated method stub
		return walletdao.FundTransfer(AccountNumber,AccNumber,pin,Balance);
	}

	@Override
	public Wallet Deposit(long AccountNumber, String pin,String balance) throws WalletException {
		// TODO Auto-generated method stub
		return walletdao.Deposit(AccountNumber, pin,balance);
	}

	@Override
	public Wallet printTransaction(Long num,String pin) throws WalletException {
		// TODO Auto-generated method stub
		return walletdao.printTransaction(num,pin);
	}

	
}
