package com.wallet.dao;

import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public interface WalletDAO {
	long createAccount(Wallet w) throws WalletException;
	public  Wallet  getAccountBalance(long AccountNumber,int pin) throws WalletException;
	public Wallet withdraw(long AccountNumber,String pin,String Balance) throws WalletException;
	public Wallet FundTransfer(long accountNumber, long accNumber, String pin, String balance)throws WalletException;
	public Wallet Deposit(long AccountNumber,String pin,String balance) throws WalletException;
	public Wallet printTransaction(Long num,String pin)throws WalletException;
}
