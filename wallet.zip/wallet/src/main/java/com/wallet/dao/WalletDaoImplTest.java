package com.wallet.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
//WalletDAO dao=new WalletDaoImpl();
WalletDAO dao=null;
@Before
public void setup() {
	dao=new WalletDaoImpl();
}

@After
public void tearDown() {
	dao = null;
}

	@Test
	public void testCreateAccount() {
		//fail("Not yet implemented");
		Wallet c = new Wallet();
		c.setAccountNumber(12345678918l);
		c.setCustomerName("Lavanya");
		c.setMobile("1234567890");
		c.setAddress("Pune");
		c.setAccountBalance(200000);
		c.setPinNumber(2222);
		
		
		try {
			dao.createAccount(c);
			 c=dao.getAccountBalance(12345678918l, 2222);
			assertNotNull(c);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetAccountBalance() {
		//fail("Not yet implemented");
		try {
			Wallet c = dao.getAccountBalance(12345678917l,7234);
			assertNotNull(c);
			Wallet c1 = dao.getAccountBalance(12345678916l,6234);
			assertNotNull(c1);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testWithdraw() {
		//fail("Not yet implemented");
		try {
			assertEquals(true, dao.withdraw(12345678918l, "2000","20000"));
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testFundTransfer() {
		//fail("Not yet implemented");
		try {
			
			assertNotEquals(true, dao.Deposit(12345678917l, "8234","20000"));
			assertNotEquals(true, dao.withdraw(12345678916l, "7234","20000"));
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testDeposit() {
		//fail("Not yet implemented");
		try {
			assertNotEquals(true, dao.Deposit(12345678917l, "8234","20000"));
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		//fail("Not yet implemented");
		try {
			Wallet b = dao.printTransaction(12345678918l,"1234");
			assertNotNull(b);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
