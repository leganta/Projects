package com.wallet.dao;


import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import com.wallet.bean.Wallet;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;

public class WalletDaoImpl implements WalletDAO {
	static HashMap<Long,Wallet> walletMap=WalletDB.getwalletMap();

	@Override
	public long createAccount(Wallet w) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Wallet wa=walletMap.get(w.getAccountNumber());
			if(walletMap.size()==0) {
				w.setAccountNumber(1234567891);
			}
			else {
				Optional<Long> w1=walletMap.keySet().stream().max(new Comparator<Long>(){

					@Override
					public int compare(Long x, Long y) {
						// TODO Auto-generated method stub
						
						return x>y?1:x<y?-1:0;
					}
					
				});
				long reqnum=w1.get()+1;
				w.setAccountNumber(reqnum);
			}
			walletMap.put(w.getAccountNumber(), w);
			return w.getAccountNumber();
		}
			catch (Exception ex) {
				throw new WalletException(ex.getMessage());
			}
	}

	@Override
	public Wallet getAccountBalance(long AccountNumber,int pin) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Wallet balance=walletMap.get(AccountNumber);
			if(balance==null) {
				throw new WalletException("Invalid Balance");
				
			}
			
			return balance;
		}
		catch(Exception ex){
			throw new WalletException(ex.getMessage());
		}
		
	}

	@Override
	public Wallet withdraw(long AccountNumber, String pin, String Balance) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Wallet bal=walletMap.get(AccountNumber);
			if(bal==null) {
				throw new WalletException("Invalid Balance");
			}
			if(bal.getPinNumber()==Integer.parseInt(pin)) {
				if(bal.getAccountBalance() >= Double.parseDouble(Balance)) {
					double balance=bal.getAccountBalance()-Double.parseDouble(Balance);
					bal.setAccountBalance(balance);
					return bal;
				}
				else {
					System.out.println("Low Balance");
				}
			}
			else {
				throw new WalletException("Invalid Balance");
			}
			
		}
		catch(Exception ex){
			throw new WalletException(ex.getMessage());
		}
		
		return null;
	}



	@Override
	public Wallet FundTransfer(long accountNumber, long accNumber, String pin, String balance) {
		// TODO Auto-generated method stub
		try {
			Wallet b=walletMap.get(accountNumber);
			Wallet ob=walletMap.get(accNumber);
			if(b==null || ob==null) {
				throw new WalletException("Invalid Balance");
			}
			if(b.getPinNumber()==Integer.parseInt(pin)) {
			if(b.getAccountBalance() >= Double.parseDouble(balance)) {
				double balance1=b.getAccountBalance()-Double.parseDouble(balance);
				b.setAccountBalance(balance1);
				double obalance = ob.getAccountBalance()+Double.parseDouble(balance);
				ob.setAccountBalance(obalance);
				return b;
			}
			else {
				System.out.println("Low Balance");
			}
			}
			else {
				throw new WalletException("Invalid Balance");
			}
			
			
			return b;
		}
		catch(Exception ex){
			try {
				throw new WalletException(ex.getMessage());
			} catch (WalletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public Wallet Deposit(long AccountNumber, String pin,String balance) throws WalletException {
		// TODO Auto-generated method stub
		try {
			
			Wallet ba=walletMap.get(AccountNumber);
			if(ba==null) {
				throw new WalletException("customer with the account number "+AccountNumber+" Not existed");
			}
			if(ba.getPinNumber()==Integer.parseInt(pin)) {
			double balance1=ba.getAccountBalance() + Double.parseDouble(balance);
			ba.setAccountBalance(balance1);
			
			return ba;
			}
			else {
				throw new WalletException("Invalid user");
			}
			}
		catch(WalletException ex) {
			System.out.println(ex.getMessage());
		}
		return null;
	}

	@Override
	public Wallet printTransaction(Long num,String pin) throws WalletException {
		// TODO Auto-generated method stub
				try {
					Wallet bala=walletMap.get(num);

					if (bala == null) {
						throw new WalletException("Employee with Id:" + num + "Not available in the database");
					}
					return bala;
				} catch (WalletException ex) {
					throw new WalletException(ex.getMessage());
				}
		
	}
}