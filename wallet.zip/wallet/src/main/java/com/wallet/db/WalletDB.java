package com.wallet.db;

import java.util.HashMap;

import com.wallet.bean.Wallet;

public class WalletDB {
private static HashMap<Long,Wallet>
walletMap=new HashMap<Long,Wallet>();
static {
	walletMap.put(12345678912l, new Wallet("Lavanya", 23456, "Savings", 12345678912l, 
			"9876543210", "Chennai", 1234));
	walletMap.put(12345678913l, new Wallet("Lakshmi", 33456, "Current", 12345678913l, 
			"9876543211", "Hyderabad", 4321));
	walletMap.put(12345678914l, new Wallet("SriHari", 43456, "Savings", 12345678914l, 
			"9876543212", "Bangalore", 5234));
	walletMap.put(12345678915l, new Wallet("Krishna", 53456, "Current", 12345678915l, 
			"9876543213", "Canada", 6234));
	walletMap.put(12345678916l, new Wallet("Satish", 63456, "Savings", 12345678916l, 
			"9876543214", "kerala", 7234));
	walletMap.put(12345678917l, new Wallet("Vamsi", 73456, "Current", 12345678917l, 
			"9876543215", "Maharastra", 8234));
}
public static HashMap<Long, Wallet> getwalletMap() {
	// TODO Auto-generated method stub
	return walletMap;
}

}
