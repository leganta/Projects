package com.walletjdbc.dao;

import com.walletjdbc.bean.Wallet;
import com.walletjdbc.exception.WalletJdbcException;

public interface WalletJdbcDao {

	public	Wallet FundTransfer(Long num, Long num1, String pin, String balance)throws WalletJdbcException ;

	public	boolean printTransaction(Long num, String pin)throws WalletJdbcException;

	public Wallet withdraw(Long num, String pin, String balance)throws WalletJdbcException;

	public Wallet Deposit(Long num, String pin, String balance)throws WalletJdbcException;

	public	Wallet getAccountBalance(Long num, int pin)throws WalletJdbcException;

	public	long createAccount(Wallet w)throws WalletJdbcException;

}
