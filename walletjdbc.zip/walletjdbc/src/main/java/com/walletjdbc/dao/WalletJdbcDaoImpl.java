package com.walletjdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employeeapp.exception.EmployeeException;
import com.capgemini.employeeapp.util.DBConnection;
import com.walletjdbc.bean.TransactionDetails;
import com.walletjdbc.bean.Wallet;
import com.walletjdbc.exception.WalletJdbcException;

public class WalletJdbcDaoImpl implements WalletJdbcDao {
	Logger logger=Logger.getRootLogger();
public WalletJdbcDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	
	@Override
	public Wallet FundTransfer(Long num, Long num1, String pin, String bal)throws WalletJdbcException {
		// TODO Auto-generated method stub
		Wallet w=new Wallet();
		Connection connection = null;
		
		try {
			connection = DBConnection.getInstance().getConnection();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		PreparedStatement spreparedStatement=null;	
		PreparedStatement spreparedStatement1=null;	
		PreparedStatement upreparedStatement=null;	
		PreparedStatement upreparedStatement1=null;	
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		ResultSet oresultSet = null;
		ResultSet oresultSet1 = null;
		try {
			spreparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			spreparedStatement.setLong(1, num);			
			resultSet=spreparedStatement.executeQuery();
			spreparedStatement1=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			spreparedStatement1.setLong(1, num1);			
			oresultSet=spreparedStatement1.executeQuery();
			
			if(resultSet.next() )
			{
				
				if((Integer.parseInt(pin)==resultSet.getInt("PinNumber"))) {
						
						double balance=resultSet.getDouble("AccountBalance");
						if(balance < Double.parseDouble(bal)) {
							throw new WalletJdbcException("Insufficient balance");
						}
						else {
						
						double newbal=balance - Double.parseDouble(bal);
						//System.out.println("haiii");
						upreparedStatement=connection.prepareStatement(QueryMapper.UPDATE_QUERY);
						upreparedStatement.setDouble(1, newbal);
						upreparedStatement.setLong(2, num);
						resultSet1=upreparedStatement.executeQuery();
								
						if(oresultSet.next())
						{
						double balance1=oresultSet.getDouble("AccountBalance");
						double othbal=balance1 + Double.parseDouble(bal);
						upreparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_QUERY);
						upreparedStatement1.setDouble(1,othbal);
						upreparedStatement1.setLong(2,num1);
					                                    
						oresultSet1=upreparedStatement1.executeQuery();
						}				
						
						else{
							System.err.println("customer with the account number "+num1+" Not existed");
						}
						w.setAccountBalance(newbal);
						w.setAccountNumber(num);
						w.setCustomerName(resultSet.getString("CustomerName"));
						
						PreparedStatement transStatement = connection.prepareStatement(QueryMapper.TRANSINSERT_QUERY);
						transStatement.setLong(1, num);
						transStatement.setString(2, "Fund Transfer");
						transStatement.setDouble(3, Double.parseDouble(bal));
					PreparedStatement date1=connection.prepareStatement("select sysdate from dual");
						ResultSet r1=date1.executeQuery();
						if(r1.next()) {
							
						Date d=r1.getDate(1);
						transStatement.setDate(4, d);
						}
						
						int queryResult = transStatement.executeUpdate();
						transStatement = connection.prepareStatement(QueryMapper.TRANSID_QUERY_SEQUENCE);
						ResultSet result = transStatement.executeQuery();
						if(result.next())
						{
							int transid = resultSet.getInt(1);
									
						}
									return w;
						}
									}
			
					
					else {
						
						System.err.println("Enter the correct pin.Invalid User");
						
					}
			}
				else {
					System.err.println("customer with the account number "+num+" Not existed");
				}
			
		
				}
	catch(SQLException sqlException)
	{
		
		throw new WalletJdbcException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			spreparedStatement.close();
			spreparedStatement1.close();
			upreparedStatement.close();
			upreparedStatement1.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletJdbcException("Error in closing db connection");	
		}
	}
		return null;
	}

	@Override
	public boolean printTransaction(Long num, String pin) throws WalletJdbcException{
		// TODO Auto-generated method stub
		
		Wallet w=new Wallet();
		TransactionDetails td=new TransactionDetails();
		Connection connection = null;
		
		try {
			connection = DBConnection.getInstance().getConnection();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement preparedStatement=null;
		PreparedStatement transStatement=null;
		ResultSet resultSet = null;
		ResultSet transresult=null;
		try {
					
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, num);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				if((Integer.parseInt(pin)!=resultSet.getInt("PinNumber"))) {
						     System.err.println("Enter the correct pin.Invalid User");
						       }	
					         else {
					        	 transStatement=connection.prepareStatement(QueryMapper.TRANSSELECT_QUERY);
					 			transStatement.setLong(1, num);
					 			transresult=transStatement.executeQuery();
					 			while(transresult.next()) {
					 				td.setTransType(transresult.getString("transtype"));
					 				td.setAmount(transresult.getDouble("balance"));
					 				//w.setCustomerName(transresult.getString("CustomerName"));
					 				//w.setAccountNumber(num);
					 				td.setDot(transresult.getDate("transdate"));
					 				System.out.println(td);
					 			}
		                        }
                   }
		else {
			System.err.println("customer with the account number "+num+" Not existed");
		}
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			throw new WalletJdbcException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new WalletJdbcException("Error in closing db connection");	
			}
		}
			
			return false;
	}

	@Override
	public Wallet withdraw(Long num, String pin, String balance)throws WalletJdbcException {
		// TODO Auto-generated method stub
		Wallet w=new Wallet();
		Connection connection = null;
		
		try {
			connection = DBConnection.getInstance().getConnection();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PreparedStatement preparedStatement=null;	
		PreparedStatement preparedStatement1=null;	
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, num);			
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
					if((Integer.parseInt(pin)==resultSet.getInt("PinNumber"))) {
						
						double balance1=resultSet.getDouble("Accountbalance");
						if(balance1 < Double.parseDouble(balance)) {
							throw new WalletJdbcException("Insufficient balance");
						}
						else {
						double newbal=balance1 - Double.parseDouble(balance);
						
						preparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_QUERY);
						preparedStatement1.setDouble(1, newbal);
						preparedStatement1.setLong(2, num);
						resultSet1=preparedStatement1.executeQuery();
						w.setAccountBalance(newbal);
						w.setAccountNumber(num);
						w.setCustomerName(resultSet.getString("CustomerName"));
						PreparedStatement transStatement = connection.prepareStatement(QueryMapper.TRANSINSERT_QUERY);
						transStatement.setLong(1, num);
						transStatement.setString(2, "Withdraw");
						transStatement.setDouble(3, Double.parseDouble(balance));
					PreparedStatement date1=connection.prepareStatement("select sysdate from dual");
						ResultSet r1=date1.executeQuery();
						if(r1.next()) {
							
						Date d=r1.getDate(1);
						transStatement.setDate(4, d);
						}
						
						int queryResult = transStatement.executeUpdate();
						transStatement = connection.prepareStatement(QueryMapper.TRANSID_QUERY_SEQUENCE);
						ResultSet result = transStatement.executeQuery();
						if(result.next())
						{
							int transid = resultSet.getInt(1);
									
						}
												return w;
						}
				}	
					else {
						
						System.err.println("Enter the correct pin.Invalid User");
						
					}
				}
				else {
					System.err.println("customer with the account number "+num+" Not existed");
				}
			
		
				}
	catch(SQLException sqlException)
	{
		
		throw new WalletJdbcException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			preparedStatement1.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletJdbcException("Error in closing db connection");	
		}
	}
		return null;
		
	}

	@Override
	public Wallet Deposit(Long num, String pin, String balance)throws WalletJdbcException {
		// TODO Auto-generated method stub
		Wallet w=new Wallet();
		Connection connection = null;
		try {
			connection = DBConnection.getInstance().getConnection();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		PreparedStatement transStatement=null;
		PreparedStatement preparedStatement=null;	
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet = null;
ResultSet resultSet1 = null;
		
		int queryResult=0;
		try {
			

			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, num);			
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				if((Integer.parseInt(pin)==resultSet.getInt("PinNumber"))) {
						
						double balance1=resultSet.getDouble("AccountBalance");
						double newbal=balance1 + Double.parseDouble(balance);
						preparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_QUERY);
						preparedStatement1.setDouble(1, newbal);
						preparedStatement1.setLong(2, num);
					
						resultSet1=preparedStatement1.executeQuery();
						w.setAccountBalance(newbal);
						w.setAccountNumber(num);
						w.setCustomerName(resultSet.getString("CustomerName"));
						transStatement=connection.prepareStatement(QueryMapper.TRANSINSERT_QUERY);
						transStatement.setLong(1, num);
						transStatement.setString(2, "Deposite");
						transStatement.setDouble(3, Double.parseDouble(balance));
					PreparedStatement date1=connection.prepareStatement("select sysdate from dual");
						ResultSet r1=date1.executeQuery();
						if(r1.next()) {
							
						Date d=r1.getDate(1);
						transStatement.setDate(4, d);
						}
						
						queryResult=transStatement.executeUpdate();
						transStatement = connection.prepareStatement(QueryMapper.TRANSID_QUERY_SEQUENCE);
						ResultSet result = transStatement.executeQuery();
						if(result.next())
						{
							int transid = resultSet.getInt(1);
									
						}
						return w;
				}	
					else {
						
						System.err.println("Enter the correct pin.Invalid User");
						
					}
				}
				else {
					System.err.println("customer with the account number "+num+" Not existed");
				}
			
		
				}
	catch(SQLException sqlException)
	{
		sqlException.printStackTrace();
		throw new WalletJdbcException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletJdbcException("Error in closing db connection");	
		}
	}
		return null;
	}

	@Override
	public Wallet getAccountBalance(Long num, int pin) throws WalletJdbcException{
		// TODO Auto-generated method stub
		Wallet w=new Wallet();
		Connection connection = null;
		try {
			connection = DBConnection.getInstance().getConnection();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			preparedStatement.setLong(1, num);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				
				if(((pin)!=resultSet.getInt("PinNumber"))) {
						System.err.println("Enter the correct pin.Invalid User");
						}	
					else {
						double balance=resultSet.getDouble("AccountBalance");
					w.setAccountBalance(balance);
						w.setAccountNumber(num);
						w.setCustomerName(resultSet.getString("CustomerName"));
						//System.out.println(balance);
						return w;
						
					}
				}
				else {
					System.err.println("customer with the account number "+num+" Not existed");
				}
				}
	catch(SQLException sqlException)
	{
		throw new WalletJdbcException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			throw new WalletJdbcException("Error in closing db connection");	
		}
	}
		
		
		return null;
	
	}

	@Override
	public long createAccount(Wallet w) throws WalletJdbcException{
		// TODO Auto-generated method stub
		Connection connection = null;
		try {
			connection = DBConnection.getInstance().getConnection();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int AccountNumber=0;
		
		int queryResult=0;
		try
		{		

			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			//preparedStatement.setLong(1,w.getAccountNumber());
			preparedStatement.setString(1,w.getCustomerName());
			preparedStatement.setDouble(2,w.getAccountBalance());
			preparedStatement.setString(3,w.getAccountType());
			preparedStatement.setString(4,w.getMobile());
			preparedStatement.setString(5,w.getAddress());
			preparedStatement.setInt(6,w.getPinNumber());
			preparedStatement.setString(7,w.getTransaction());
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.
					 ACCOUNTNUMBER_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				AccountNumber=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletJdbcException("Inserting Customer details failed ");

			}
			else
			{
				logger.info("Customer details added successfully:");
				return AccountNumber;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletJdbcException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletJdbcException("Error in closing db connection");	
			}
		}
		


	}
}
