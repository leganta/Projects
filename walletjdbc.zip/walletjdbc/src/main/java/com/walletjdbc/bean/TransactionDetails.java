package com.walletjdbc.bean;

import java.sql.Date;
import java.time.LocalDateTime;

public class TransactionDetails {
private double amount;
private Long accnum;
private int transid;
private String transType;
private Date dot;
public Long getAccnum() {
	return accnum;
}
public void setAccno(Long accnum) {
	this.accnum = accnum;
}

public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getTransType() {
	return transType;
}
public void setTransType(String transType) {
	this.transType = transType;
}
public Date getDot() {
	return dot;
}
public void setDot(Date date) {
	this.dot = date;
}

@Override
public String toString() {
	return "Transaction Type=" + transType + ", Amount=" + amount + ", Date "+dot ;
}
}
