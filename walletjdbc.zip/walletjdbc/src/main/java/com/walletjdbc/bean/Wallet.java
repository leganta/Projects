package com.walletjdbc.bean;

import java.sql.Date;

public class Wallet {
private String CustomerName;
private double AccountBalance;
private String AccountType;
private long AccountNumber;
private String Mobile;
private String Address;
private int PinNumber;
private String Transaction;



public Wallet(String customerName, double accountBalance, String accountType, long accountNumber, String mobile,
		String address, int pinNumber, String transaction) {
	super();
	CustomerName = customerName;
	AccountBalance = accountBalance;
	AccountType = accountType;
	AccountNumber = accountNumber;
	Mobile = mobile;
	Address = address;
	PinNumber = pinNumber;
	Transaction = transaction;
}



public Wallet() {
	// TODO Auto-generated constructor stub
}



public String getCustomerName() {
	return CustomerName;
}



public void setCustomerName(String customerName) {
	CustomerName = customerName;
}



public double getAccountBalance() {
	return AccountBalance;
}



public void setAccountBalance(double accountBalance) {
	AccountBalance = accountBalance;
}



public String getAccountType() {
	return AccountType;
}



public void setAccountType(String accountType) {
	AccountType = accountType;
}



public long getAccountNumber() {
	return AccountNumber;
}



public void setAccountNumber(long accountNumber) {
	AccountNumber = accountNumber;
}



public String getMobile() {
	return Mobile;
}



public void setMobile(String mobile) {
	Mobile = mobile;
}



public String getAddress() {
	return Address;
}



public void setAddress(String address) {
	Address = address;
}



public int getPinNumber() {
	return PinNumber;
}



public void setPinNumber(int pinNumber) {
	PinNumber = pinNumber;
}



public String getTransaction() {
	return Transaction;
}



public void setTransaction(String transaction) {
	Transaction = transaction;
}



@Override
public String toString() {
	return "Wallet [CustomerName=" + CustomerName + ", AccountBalance=" + AccountBalance + ", "
			+ "AccountNumber=" + AccountNumber + ",Transaction="+Transaction+"]";
}





}
