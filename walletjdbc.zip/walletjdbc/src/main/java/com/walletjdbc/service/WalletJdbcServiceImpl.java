package com.walletjdbc.service;


import com.walletjdbc.bean.Wallet;
import com.walletjdbc.dao.WalletJdbcDao;
import com.walletjdbc.dao.WalletJdbcDaoImpl;
import com.walletjdbc.exception.WalletJdbcException;

public class WalletJdbcServiceImpl implements WalletJdbcService {

	WalletJdbcDao walletjdbcdao=new WalletJdbcDaoImpl();
	@Override
	public long createAccount(Wallet w) throws WalletJdbcException {
		// TODO Auto-generated method stub
		return walletjdbcdao.createAccount(w);
	}

	@Override
	public boolean validateAccount(Wallet w) throws WalletJdbcException {
		// TODO Auto-generated method stub
		if(validateName(w.getCustomerName())&& validateMobile(w.getMobile())) {
			return true;
		}
		
		return false;
	}
	private boolean validateName(String name) throws WalletJdbcException {
		if(name.isEmpty() || name==null) {
			throw new WalletJdbcException("Employee Name cannot be Empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletJdbcException("Name should start with Capital Letter "
						+ "followed by Minimum of 2 Alphabets");
			}
		}
		
		return true;
		
	}
	private boolean validateMobile(String mobile) throws WalletJdbcException{
		if(mobile.isEmpty() || mobile==null) {
			throw new WalletJdbcException("Mobile Number is Mandatory");
		}
		else {
			if(!mobile.matches("\\d{10}")) {
			throw new WalletJdbcException("Mobile Number should contain only 10 digits");	
			}
		}
		
		return true;
	}


	@Override
	public Wallet getAccountBalance(Long AccountNumber,int pin) throws WalletJdbcException {
		// TODO Auto-generated method stub
		return walletjdbcdao.getAccountBalance(AccountNumber,pin);
	}

	@Override
	public Wallet withdraw(Long AccountNumber, String pin, String Balance) throws WalletJdbcException {
		// TODO Auto-generated method stub
		return walletjdbcdao.withdraw(AccountNumber,pin,Balance);
	}

	@Override
	public Wallet FundTransfer(Long AccountNumber, Long AccNumber, String pin, String Balance) throws WalletJdbcException {
		// TODO Auto-generated method stub
		return walletjdbcdao.FundTransfer(AccountNumber,AccNumber,pin,Balance);
	}

	@Override
	public Wallet Deposit(Long AccountNumber, String pin,String balance) throws WalletJdbcException {
		// TODO Auto-generated method stub
		return walletjdbcdao.Deposit(AccountNumber, pin,balance);
	}

	@Override
	public boolean printTransaction(Long num,String pin) throws WalletJdbcException {
		// TODO Auto-generated method stub
		return walletjdbcdao.printTransaction(num,pin);
	}

}
