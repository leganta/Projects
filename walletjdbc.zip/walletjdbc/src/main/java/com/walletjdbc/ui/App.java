package com.walletjdbc.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.walletjdbc.bean.Wallet;
import com.walletjdbc.exception.WalletJdbcException;
import com.walletjdbc.service.WalletJdbcService;
import com.walletjdbc.service.WalletJdbcServiceImpl;

/**
 * Hello world!
 *
 */
public class App{ 
	
	WalletJdbcService walletJdbcService= new WalletJdbcServiceImpl();
Scanner scan= new Scanner(System.in);
static Logger logger = Logger.getRootLogger();
    public static void main( String[] args ) throws WalletJdbcException
    {
    	PropertyConfigurator.configure("resources//log4j.properties");
        String option = null;
        App a= new App();
        while(true) {
        	System.out.println("====Account Management System====");
        	System.out.println("1.Create Bank Account");
        	System.out.println("2.Show Account Balance");
        	System.out.println("3.Deposit");
        	System.out.println("4.Withdraw");
        	System.out.println("5.Print Transaction");
        	System.out.println("6.Fund Transfer");
        	System.out.println("7.Exit");
        	System.out.println("Choose an option");
        option = a.scan.nextLine();
        	switch(option) {
        	case"1":
        	
					a.createAccount();
		
        		break;
        	case"2":
        		a.showAccountBalance();
        		break;
        	case"3":
        		a.deposit();
        		break;
        	case"4":
        	
					a.withdraw();
				
        		break;
        	case"5":
        		a.printTransaction();
        		break;
        	case"6":
        		
					a.fundTransfer();
		
        		break;
        	case"7":
        		System.exit(0);
        		break;
        	default:
        		System.err.println("Enter option between 1 to 7");
        		System.out.println();
        		
        	}
        }
    }

	private void fundTransfer() throws WalletJdbcException {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Other Account Number");
		Long num1=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		String pin=(scan.nextLine());
		System.out.println("Enter Balance to Transfer");
		String balance=((scan.nextLine()));
		try {
			Wallet request=walletJdbcService.FundTransfer(num,num1, pin, balance);
			System.out.println(request);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			
			logger.error("exception occured", e);
			System.out.println();
			//System.err.println("An error Occured:"+e.getMessage());
			System.out.println();
		}
	}

	private void printTransaction() {
		// TODO Auto-generated method stub
		System.out.println("Enter account number:");
		long num = Long.parseLong(scan.nextLine());
		System.out.println("Enter pin");
		String pin = (scan.nextLine());
		try {
			boolean request=walletJdbcService.printTransaction(num,pin);
			if(pin==null) {
			System.out.println("invalid pin");
			}
			/*else {
				//System.out.println("Transaction statement:");
			
			//System.out.println();
			System.out.println(request);
			//System.out.println();
			}*/	
	
		}
		catch (WalletJdbcException e) {
			logger.error("exception occured", e);
			System.err.println("An Error Occured " + e.getMessage());

		}
	}

	private void withdraw() throws WalletJdbcException {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		String pin=(scan.nextLine());
		System.out.println("Enter Balance to Withdraw");
		String balance=((scan.nextLine()));
		try {
			Wallet request=walletJdbcService.withdraw(num, pin, balance);
			System.out.println(request);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			
			logger.error("exception occured", e);
			//System.err.println("An error Occured:"+e.getMessage());
			System.out.println();
		}
	}

	private void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		String pin=((scan.nextLine()));
		System.out.println("Enter Balance to Deposit");
		String balance=((scan.nextLine()));
		
		try {
			//double Balance=Double.parseDouble(num);
				Wallet request=walletJdbcService.Deposit(num,pin,balance);
				System.out.println(request);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
				logger.error("exception occured", e);
				System.err.println("An error Occured:"+e.getMessage());
				System.out.println();
			}
	}

	private void showAccountBalance() {
		// TODO Auto-generated method stub
		System.out.println("Enter Account Number");
		Long num=(Long.parseLong(scan.nextLine()));
		System.out.println("Enter Pin Number");
		int pin=(Integer.parseInt(scan.nextLine()));
		try {
			//double Balance=Double.parseDouble(num);
				Wallet request=walletJdbcService.getAccountBalance(num,pin);
				System.out.println(request);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
				logger.error("exception occured", e);
				System.err.println("An error Occured:"+e.getMessage());
				System.out.println();
			}
			
		
	}

	private void createAccount() throws WalletJdbcException {
		// TODO Auto-generated method stub
		Wallet w=new Wallet();
		System.out.println("Enter Customer Name");
		w.setCustomerName(scan.nextLine());
		/*System.out.println("Enter Account Number");
		w.setAccountNumber(Long.parseLong(scan.nextLine()));*/
		System.out.println("Enter Account Type");
		w.setAccountType(scan.nextLine());
		System.out.println("Enter Account Balance");
		w.setAccountBalance(Double.parseDouble(scan.nextLine()));

		System.out.println("Enter Mobile Number");
		w.setMobile(scan.nextLine());
		System.out.println("Enter pin");
		w.setPinNumber(Integer.parseInt(scan.nextLine()));
		System.out.println("Enter Address");
		w.setAddress(scan.nextLine());
		System.out.println("Enter Transaction");
		w.setTransaction(scan.nextLine());
		boolean result=walletJdbcService.validateAccount(w);
		if(result) {
			long ret=walletJdbcService.createAccount(w);
			System.out.println("Customer with Account "+ ret+"Added Successfully");
		}
	}
}
