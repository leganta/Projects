package com.walletjdbc.exception;

public class WalletJdbcException extends Exception{
	
		private static final long serialVersionUID = 726264577455921591L;

		public WalletJdbcException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}
}
