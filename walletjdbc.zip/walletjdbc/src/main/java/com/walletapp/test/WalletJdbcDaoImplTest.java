package com.walletapp.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.walletjdbc.bean.Wallet;
import com.walletjdbc.dao.WalletJdbcDao;
import com.walletjdbc.dao.WalletJdbcDaoImpl;
import com.walletjdbc.exception.WalletJdbcException;

public class WalletJdbcDaoImplTest {
	WalletJdbcDao dao=null;

    @Before
    public void setup() {
           dao=new WalletJdbcDaoImpl();
    }
    
    @After
    public void tearDown() {
           dao = null;
    }
	@Test
	public void testWalletJdbcDaoImpl() {
		//fail("Not yet implemented");
		
 }
		

	@Test
	public void testFundTransfer() throws WalletJdbcException {
		//fail("Not yet implemented");
		Wallet w=new Wallet();
	  	   w.setAccountNumber(53L);
	  	   w.setCustomerName("Ben");
	  	   w.setAccountBalance(2343445.33);
	  	 assertNotSame(w, dao.FundTransfer(81L,53L,"1256","100"));
		
	}

	@Test
	public void testPrintTransaction() throws WalletJdbcException {
		//fail("Not yet implemented");
		assertFalse(dao.printTransaction(81l, "1256"));
	}

	@Test
	public void testWithdraw() throws WalletJdbcException {
		//fail("Not yet implemented");
		Wallet w=new Wallet();
	  	   w.setAccountNumber(81L);
	  	   w.setCustomerName("Ben");
	  	   w.setAccountBalance(1886700.00);
	  	 assertNotSame(w, dao.withdraw(53L,"0987","2000"));
	}

	@Test
	public void testDeposit() throws WalletJdbcException {
		//fail("Not yet implemented");
		Wallet w=new Wallet();
	  	   w.setAccountNumber(53L);
	  	   w.setCustomerName("Ben");
	  	   w.setAccountBalance(2343445.33);
	            assertNotSame(w, dao.Deposit(81l,"1256","1000"));
	}

	@Test
	public void testGetAccountBalance() {
		//fail("Not yet implemented");
		try {
			Wallet w = dao.getAccountBalance(81L,1256);
                 assertNotNull(w);
                 Wallet w1 = dao.getAccountBalance(82L,1256);
                 assertNull(w1);
          } catch (WalletJdbcException e) {
                 // TODO Auto-generated catch block
                 System.out.println(e.getMessage());
          }
	}

	@Test
	public void testCreateAccount() {
		//fail("Not yet implemented");
		Wallet w=new Wallet();
        w.setAccountNumber(21L);
        w.setCustomerName("Prani");
        w.setMobile("1234567890");
        w.setAddress("Pune");
        w.setAccountBalance(200000);
        w.setPinNumber(1122);
        
        
        try {
               dao.createAccount(w);
               Wallet c1=dao.getAccountBalance(81L,1256);
               assertNotNull(c1);
        } catch (WalletJdbcException e) {
               // TODO Auto-generated catch block
               System.out.println(e.getMessage());
        }
	}

}
